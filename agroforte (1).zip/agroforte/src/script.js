// Inicializa os ícones modernos do Lucide
lucide.createIcons();

// Animação dos Contadores de Estatísticas
const counters = document.querySelectorAll('.counter');
const speed = 50; // Quanto menor, mais rápido

const startCounters = () => {
    counters.forEach(counter => {
        const updateCount = () => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const inc = Math.ceil(target / speed);

            if (count < target) {
                counter.innerText = count + inc;
                setTimeout(updateCount, 20);
            } else {
                counter.innerText = target;
            }
        };
        updateCount();
    });
};

// Disparar os contadores quando o usuário rolar até a seção
let animated = false;
window.addEventListener('scroll', () => {
    const statsSection = document.querySelector('.stats');
    if (statsSection) {
        const position = statsSection.getBoundingClientRect().top;
        const screenPosition = window.innerHeight;
        
        if (position < screenPosition && !animated) {
            startCounters();
            animated = true;
        }
    }
});

// Validação e Feedback do Formulário de Contato
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const nome = document.getElementById('nome').value;
    const feedback = document.getElementById('formFeedback');
    
    // Simulação de envio com sucesso
    feedback.innerText = `Obrigado pelo contato, ${nome}! Nossa equipe do Agro Forte responderá em breve.`;
    feedback.className = "success";
    
    // Limpa o formulário
    this.reset();
});